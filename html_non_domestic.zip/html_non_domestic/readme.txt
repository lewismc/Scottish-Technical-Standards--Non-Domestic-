
READ ME
navigate to the file named non_domestic.htm inside the non_domestic directory and open this in your browser.